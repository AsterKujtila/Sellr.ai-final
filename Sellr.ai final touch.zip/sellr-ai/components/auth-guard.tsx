'use client'

import { createClient } from '@/lib/supabase/client'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useRef } from 'react'

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const router   = useRouter()
  const didCheck = useRef(false)

  useEffect(() => {
    if (didCheck.current) return
    didCheck.current = true

    const supabase = createClient()

    const run = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        router.replace('/login')
        return
      }

      // Ensure profile row exists (auto-created by trigger, but safety check)
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .single()

      if (!profile) {
        // Insert manually as fallback
        await supabase.from('profiles').insert({
          id: user.id,
          name: user.user_metadata?.full_name ?? user.user_metadata?.name ?? null,
          email: user.email,
          avatar_url: user.user_metadata?.avatar_url ?? user.user_metadata?.picture ?? null,
        })
      }
    }

    run()
  }, [pathname, router])

  return <>{children}</>
}
