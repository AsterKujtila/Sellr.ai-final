export interface UserProfile {
  id: string
  name: string | null
  email: string | null
  avatar_url: string | null
  whop_store_url: string | null
  plan: 'free' | 'pro' | 'scale'
  credits_used: number
  credits_limit: number
  created_at: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  created_at?: string
}

export interface ChatSession {
  id: string
  user_id: string
  title: string
  created_at: string
  updated_at: string
}

export type Tab = 'chat' | 'offers' | 'store' | 'credits'
