import { NextResponse } from 'next/server'
import { createHash, randomBytes } from 'crypto'

function generateVerifier(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~'
  const bytes = randomBytes(56)
  let out = ''
  for (let i = 0; i < 56; i++) out += chars[bytes[i]! % chars.length]
  return out
}

function computeChallenge(verifier: string): string {
  return createHash('sha256')
    .update(verifier, 'utf8')
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '')
}

export async function GET(request: Request) {
  const { origin } = new URL(request.url)
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const redirectTo  = `${origin}/auth/callback`

  const verifier   = generateVerifier()
  const challenge  = computeChallenge(verifier)

  const authUrl = new URL('/auth/v1/authorize', supabaseUrl)
  authUrl.searchParams.set('provider',              'google')
  authUrl.searchParams.set('redirect_to',           redirectTo)
  authUrl.searchParams.set('code_challenge',        challenge)
  authUrl.searchParams.set('code_challenge_method', 'S256')

  const response = NextResponse.redirect(authUrl.toString())
  response.cookies.set('sb-pkce-verifier', verifier, {
    path:     '/',
    maxAge:   600,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    httpOnly: true,
  })
  return response
}
