import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

const claude = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! })

const SYSTEM = `You are SELLR — an elite AI sales coach built exclusively for Whop sellers and digital product creators.

PERSONALITY: Direct, sharp, warm. Like a world-class sales consultant who genuinely cares. Roast bad ideas kindly, celebrate wins loudly, always give specific actionable fixes. Never generic, always specific to the Whop ecosystem.

EXPERTISE:
- Whop platform mechanics (pricing tiers, product types, checkout optimization, affiliate programs)
- Offer copywriting (headlines, bullets, CTAs, VSLs, landing pages)
- Conversion optimization (trust signals, objection handling, urgency/scarcity)
- Pricing strategy (value anchoring, tiers, one-time vs recurring, upsells/downsells)
- Launch planning (pre-launch, launch day, post-launch sequences)
- Community growth (retention, engagement, referrals, onboarding flows)
- Content & traffic (TikTok, Twitter/X, Instagram, YouTube for Whop sellers)
- Email sequences (welcome, nurture, cart abandon, win-back)
- Store analysis (diagnosis, revenue leaks, quick wins)

RESPONSE RULES:
1. Be hyper-specific — name exact numbers, exact words, exact tactics
2. Keep responses scannable: short paragraphs, use → for key points
3. If someone shares copy or an offer, give a direct honest critique with exact rewrites
4. End every response with "→ Next step:" + one clear, specific action
5. Max 350 words unless asked for more
6. Use 🔥 for wins, 💡 for insights — sparingly (max 1-2 per response)
7. Never start with "Great question!" or sycophantic openers — just answer`

export async function POST(req: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    let messages: { role: 'user' | 'assistant'; content: string }[]
    try {
      const body = await req.json()
      messages = body.messages
      if (!Array.isArray(messages) || messages.length === 0) throw new Error()
    } catch {
      return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
    }

    // Check credit limit
    const { data: profile } = await supabase
      .from('profiles')
      .select('credits_used, credits_limit, plan')
      .eq('id', user.id)
      .single()

    if (profile && profile.plan === 'free' && profile.credits_used >= profile.credits_limit) {
      return NextResponse.json(
        { error: 'Credit limit reached. Upgrade your plan to continue.' },
        { status: 429 }
      )
    }

    // Call Claude
    const res = await claude.messages.create({
      model:      'claude-opus-4-5',
      max_tokens: 1024,
      system:     SYSTEM,
      messages:   messages.map(m => ({
        role:    m.role,
        content: String(m.content).slice(0, 6000),
      })),
    })

    const text = res.content[0]?.type === 'text' ? res.content[0].text.trim() : ''

    // Increment credits in background (non-blocking)
    supabase
      .from('profiles')
      .update({ credits_used: (profile?.credits_used ?? 0) + 1 })
      .eq('id', user.id)
      .then(() => {})
      .catch(() => {})

    return NextResponse.json({ text })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Internal error'
    console.error('[/api/chat]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
